package com.example.fishcatch;

import android.content.Intent;
import android.view.*;
import android.widget.*;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import androidx.cardview.widget.CardView;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class fishmemo extends AppCompatActivity{
    Button button1; //뒤로가기 버튼
    ImageButton button2; //추가하기 버튼
    TextView textView1; //텍스트뷰
    TextView textView2;
    private ArrayAdapter<String> mConversationArrayAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        /*기본 코드*/
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fishmemo);

        button1 = (Button) findViewById(R.id.button1); //뒤로가기 버튼
        button2 = (ImageButton) findViewById(R.id.button2); //추가하기 버튼
        textView1 = (TextView) findViewById(R.id.textView1); //텍스트뷰
        textView2 = (TextView) findViewById(R.id.textView2); //텍스트뷰
        ListView mMessageListview = (ListView) findViewById(R.id.listView1);

        mConversationArrayAdapter = new ArrayAdapter<>(this,
                android.R.layout.simple_list_item_1);
        mMessageListview.setAdapter(mConversationArrayAdapter);


        try {
            BufferedWriter bw = new BufferedWriter(new FileWriter(getFilesDir() + "buffer2.txt", true));
            bw.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        try {
            BufferedReader br = new BufferedReader(new FileReader(getFilesDir() + "buffer2.txt"));
            String readStr = "";
            String str = null;
            String[] array;
            while ((str = br.readLine()) != null) {
                readStr += str + "\n";
                array=str.split("/");
                mConversationArrayAdapter.insert("어종명 : " +array[0]+"\n수온 : "+array[1]+"°C\n수심 : "+array[2]+"\n위치 : "+array[3]+"\n기타메모 : "+array[4], 0) ;
            }
            br.close();
        } catch (
                FileNotFoundException e) {
            e.printStackTrace();
            Toast.makeText(getApplicationContext(), "File not found", Toast.LENGTH_SHORT).show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public void goBack(View view){
        //메인화면으로 넘어가는 코드
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }

    public void goPlus(View view){
        //메모장 추가로 넘어가는 코드
        Intent intent = new Intent(this, fishadd.class);
        startActivity(intent);
    }
}
