package com.example.fishcatch;
import android.content.Intent;
import android.view.*;
import android.widget.*;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import androidx.cardview.widget.CardView;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class fishadd extends AppCompatActivity{
    private final int GET_GALLERY_IMAGE = 200;
    ImageView imageView1; //이미지뷰
    Button button1; //현재 데이턱 가져오기 버튼
    Button button2; //저장 버튼
    Button button3; //취소 버튼
    TextView textView1; //어종명 텍스트뷰
    TextView textView2; //수온 텍스트뷰
    TextView textView3; //수심 텍스트뷰
    TextView textView4; //위치 텍스트뷰
    TextView textView5; //기타메모 텍스트뷰
    EditText textPlain1;
    EditText textPlain2;
    EditText textPlain3;
    EditText textPlain4;
    EditText textPlain5;

    String arr1[]=new String[5];

    protected void onCreate(Bundle savedInstanceState) {
        /*기본 코드*/
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fishadd);

        button1=(Button) findViewById(R.id.button1); //현재 데이턱 가져오기 버튼
        button2=(Button) findViewById(R.id.button2) ; //저장 버튼
        button3=(Button) findViewById(R.id.button3); //취소 버튼

        textPlain1=(EditText) findViewById(R.id.textPlain1);
        textPlain2=(EditText) findViewById(R.id.textPlain2);
        textPlain3=(EditText) findViewById(R.id.textPlain3);
        textPlain4=(EditText) findViewById(R.id.textPlain4);
        textPlain5=(EditText) findViewById(R.id.textPlain5);



        imageView1=(ImageView) findViewById(R.id.imageView1); //이미지뷰
        imageView1.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_PICK);
                intent. setDataAndType(android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI, "image/*");
                startActivityForResult(intent, GET_GALLERY_IMAGE);
            }
        });

        button2.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                //write your code here
                Toast.makeText(getApplicationContext(),"11", Toast.LENGTH_LONG).show();
                arr1=gogo();

                Toast.makeText(getApplicationContext(),"22", Toast.LENGTH_LONG).show();
                String text = "" ;
                int i=0;
                while(i<5){
                    text+=arr1[i];
                    i++;
                }
                Toast.makeText(getApplicationContext(),"22"+text, Toast.LENGTH_LONG).show();
                try{
                    BufferedWriter bw = new BufferedWriter(new FileWriter(getFilesDir() + "buffer2.txt",true));
                    bw.write(text);
                    bw.newLine();
                    bw.close();

                    Toast.makeText(getApplicationContext(),getFilesDir() + "buffer1.txt", Toast.LENGTH_LONG).show();
                }catch(IOException e1){
                    e1.printStackTrace();
                    Toast.makeText(getApplicationContext(),"추가되었습니다.",Toast.LENGTH_SHORT).show();
                }
                goBack(view);
            }
        });

        button3.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                goBack(view);
            }
        });
    }

    public void goBack(View view){
        //어류 메모장 화면으로 넘어가는 코드
        Intent intent = new Intent(this, fishmemo.class);
        startActivity(intent);
    }


    public String[] gogo(){
        //데이터 저장 후
        String arr[]=new String[5];
        String textV1 = textPlain1.getText().toString();
        arr[0]=textPlain1.getText().toString()+"/";
        arr[1]=textPlain2.getText().toString()+"/";
        arr[2]=textPlain3.getText().toString()+"/";
        arr[3]=textPlain4.getText().toString()+"/";
        arr[4]=textPlain5.getText().toString();
        return arr;
    }
}
