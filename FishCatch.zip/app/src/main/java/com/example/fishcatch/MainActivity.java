package com.example.fishcatch;

import android.content.Intent;
import android.view.*;
import android.widget.*;

import androidx.appcompat.app.AppCompatActivity;
import android.view.ViewGroup;
import android.os.Bundle;
import android.widget.RelativeLayout;
import android.os.Bundle;

import com.google.android.gms.maps.*;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Set;
import java.util.UUID;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import net.daum.android.map.MapView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;

import android.os.Bundle;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

public class MainActivity extends AppCompatActivity implements OnMapReadyCallback {

    /*구글맵 관련 코드*/
    private android.app.FragmentManager fragmentManager;
    private MapFragment mapFragment;
    /*구글맵 관련 코드 여기까지*/

    Button button1; //어류메모장 버튼


    public static final int sub = 1001; /*다른 액티비티를 띄우기 위한 요청코드(상수)*/

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        /*기본 코드*/
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        /*구글맵 관련 코드*/
        fragmentManager = getFragmentManager();
        mapFragment = (MapFragment)fragmentManager.findFragmentById(R.id.googleMap);
        mapFragment.getMapAsync(this);
        /*구글맵 관련 코드 여기까지*/

        button1=(Button) findViewById(R.id.button1); //어류메모장 버튼
    }

    public void goMemo(View view){
        //어류 메모장 화면으로 넘어가는 코드
        Intent intent = new Intent(this, fishmemo.class);
        startActivity(intent);
    }

    public void goTrap(View view){
        //상세정보 화면으로 넘어가는 코드
        Intent intent = new Intent(this, fishtrap.class);
        startActivity(intent);
    }

    /*구글맵 관련 코드*/
    @Override
    public void onMapReady(GoogleMap googleMap) {
        //위도, 경도 넣는 부분 -> GPS 값 받아오게 수정
        //현재 설정된 위치 : 동의대학교 정보공학관
        LatLng location = new LatLng(35.145667, 129.036662);
        MarkerOptions markerOptions = new MarkerOptions();
        markerOptions.title("동의대학교"); //마커 타이틀
        markerOptions.snippet("정보공학관"); //마커 상세정보
        markerOptions.position(location); //위치 설정
        googleMap.addMarker(markerOptions); //마커 등록
        googleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(location, 16)); //확대 정도 설정
    }
    /*구글맵 관련 코드 여기까지*/



}

